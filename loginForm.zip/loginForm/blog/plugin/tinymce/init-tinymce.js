tinymce.init({
	selector:"textarea.tinymce"
});